<?php

return [
    'name' => 'Panel'
];
