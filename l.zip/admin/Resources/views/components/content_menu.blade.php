
<ul class="nav nav- mb-4">
    <li class="nav-item {{ active(['panel.pages.index'])  }}">
        <a class="nav-link pl-0" href="{{route('panel.pages.index')}}">Pages</a>
    </li>
    <li class="nav-item {{ active(['panel.menu.index'])  }}">
        <a class="nav-link" href="{{route('panel.menu.index')}}">Menu</a>
    </li>
    <!--<li class="nav-item {{ active(['panel.settings.index'])  }}">
        <a class="nav-link" href="#">Emails</a>
    </li>
    <li class="nav-item {{ active(['panel.settings.index'])  }}">
        <a class="nav-link" href="#">Translations</a>
    </li>-->

</ul>