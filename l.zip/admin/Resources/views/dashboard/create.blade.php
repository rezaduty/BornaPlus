@extends('panel::layouts.master')

@section('content')
jnknjnkjnjk
@endsection
