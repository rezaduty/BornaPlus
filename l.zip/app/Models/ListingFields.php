<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ListingFields extends Model
{
    //
    use \Spiritix\LadaCache\Database\LadaCacheTrait;
}
