<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    //
    use \Spiritix\LadaCache\Database\LadaCacheTrait;

}
