<?php return array (
  'amelia/backblaze' => 
  array (
    'providers' => 
    array (
      0 => 'Amelia\\Backblaze\\BackblazeServiceProvider',
    ),
  ),
  'anhskohbo/no-captcha' => 
  array (
    'providers' => 
    array (
      0 => 'Anhskohbo\\NoCaptcha\\NoCaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'NoCaptcha' => 'Anhskohbo\\NoCaptcha\\Facades\\NoCaptcha',
    ),
  ),
  'anlutro/l4-settings' => 
  array (
    'aliases' => 
    array (
      'Setting' => 'anlutro\\LaravelSettings\\Facade',
    ),
    'providers' => 
    array (
      0 => 'anlutro\\LaravelSettings\\ServiceProvider',
    ),
  ),
  'arrilot/laravel-widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Arrilot\\Widgets\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Widget' => 'Arrilot\\Widgets\\Facade',
      'AsyncWidget' => 'Arrilot\\Widgets\\AsyncFacade',
    ),
  ),
  'atayahmet/laravel-nestable' => 
  array (
    'providers' => 
    array (
      0 => 'Nestable\\NestableServiceProvider',
    ),
    'aliases' => 
    array (
      'Nestable' => 'Nestable\\Facades\\NestableService',
    ),
  ),
  'barryvdh/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Cors\\ServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'barryvdh/laravel-translation-manager' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\TranslationManager\\ManagerServiceProvider',
    ),
  ),
  'chumper/zipper' => 
  array (
    'providers' => 
    array (
      0 => 'Chumper\\Zipper\\ZipperServiceProvider',
    ),
    'aliases' => 
    array (
      'Zipper' => 'Chumper\\Zipper\\Zipper',
    ),
  ),
  'cornford/googlmapper' => 
  array (
    'providers' => 
    array (
      0 => 'Cornford\\Googlmapper\\MapperServiceProvider',
    ),
    'aliases' => 
    array (
      'Mapper' => 'Cornford\\Googlmapper\\Facades\\MapperFacade',
    ),
  ),
  'cviebrock/eloquent-sluggable' => 
  array (
    'providers' => 
    array (
      0 => 'Cviebrock\\EloquentSluggable\\ServiceProvider',
    ),
  ),
  'cybercog/laravel-ban' => 
  array (
    'providers' => 
    array (
      0 => 'Cog\\Laravel\\Ban\\Providers\\BanServiceProvider',
    ),
  ),
  'depsimon/laravel-wallet' => 
  array (
    'providers' => 
    array (
      0 => 'Depsimon\\Wallet\\WalletServiceProvider',
    ),
    'aliases' => 
    array (
      'Wallet' => 'Depsimon\\Wallet\\WalletFacade',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'genealabs/laravel-caffeine' => 
  array (
    'providers' => 
    array (
      0 => 'GeneaLabs\\LaravelCaffeine\\Providers\\Service',
    ),
  ),
  'grimzy/laravel-mysql-spatial' => 
  array (
    'providers' => 
    array (
      0 => 'Grimzy\\LaravelMysqlSpatial\\SpatialServiceProvider',
    ),
  ),
  'igaster/laravel-theme' => 
  array (
    'providers' => 
    array (
      0 => 'Igaster\\LaravelTheme\\themeServiceProvider',
    ),
    'aliases' => 
    array (
      'Theme' => 'Igaster\\LaravelTheme\\Facades\\Theme',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'ixudra/curl' => 
  array (
    'providers' => 
    array (
      0 => 'Ixudra\\Curl\\CurlServiceProvider',
    ),
    'aliases' => 
    array (
      'Curl' => 'Ixudra\\Curl\\Facades\\Curl',
    ),
  ),
  'jenssegers/date' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Date\\DateServiceProvider',
    ),
    'aliases' => 
    array (
      'Date' => 'Jenssegers\\Date\\Date',
    ),
  ),
  'jrean/laravel-user-verification' => 
  array (
    'providers' => 
    array (
      0 => 'Jrean\\UserVerification\\UserVerificationServiceProvider',
    ),
    'aliases' => 
    array (
      'UserVerification' => 'Jrean\\UserVerification\\Facades\\UserVerification',
    ),
  ),
  'kris/laravel-form-builder' => 
  array (
    'providers' => 
    array (
      0 => 'Kris\\LaravelFormBuilder\\FormBuilderServiceProvider',
    ),
    'aliases' => 
    array (
      'FormBuilder' => 'Kris\\LaravelFormBuilder\\Facades\\FormBuilder',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'mcamara/laravel-localization' => 
  array (
    'providers' => 
    array (
      0 => 'Mcamara\\LaravelLocalization\\LaravelLocalizationServiceProvider',
    ),
    'aliases' => 
    array (
      'LaravelLocalization' => 'Mcamara\\LaravelLocalization\\Facades\\LaravelLocalization',
    ),
  ),
  'nahid/talk' => 
  array (
    'providers' => 
    array (
      0 => 'Nahid\\Talk\\TalkServiceProvider',
    ),
    'aliases' => 
    array (
      'Talk' => 'Nahid\\Talk\\Facades\\Talk',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nwidart/laravel-modules' => 
  array (
    'providers' => 
    array (
      0 => 'Nwidart\\Modules\\LaravelModulesServiceProvider',
    ),
    'aliases' => 
    array (
      'Module' => 'Nwidart\\Modules\\Facades\\Module',
    ),
  ),
  'overtrue/laravel-follow' => 
  array (
    'providers' => 
    array (
      0 => 'Overtrue\\LaravelFollow\\FollowServiceProvider',
    ),
  ),
  'propaganistas/laravel-disposable-email' => 
  array (
    'providers' => 
    array (
      0 => 'Propaganistas\\LaravelDisposableEmail\\DisposableEmailServiceProvider',
    ),
  ),
  'pulkitjalan/geoip' => 
  array (
    'providers' => 
    array (
      0 => 'PulkitJalan\\GeoIP\\GeoIPServiceProvider',
    ),
    'aliases' => 
    array (
      'GeoIP' => 'PulkitJalan\\GeoIP\\Facades\\GeoIP',
    ),
  ),
  'rcrowe/twigbridge' => 
  array (
    'providers' => 
    array (
      0 => 'TwigBridge\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Twig' => 'TwigBridge\\Facade\\Twig',
    ),
  ),
  'roumen/sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Roumen\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'socialiteproviders/manager' => 
  array (
    'providers' => 
    array (
      0 => 'SocialiteProviders\\Manager\\ServiceProvider',
    ),
  ),
  'sofa/eloquence-base' => 
  array (
    'providers' => 
    array (
      0 => 'Sofa\\Eloquence\\BaseServiceProvider',
    ),
  ),
  'sofa/eloquence-mutable' => 
  array (
    'providers' => 
    array (
      0 => 'Sofa\\Eloquence\\MutableServiceProvider',
    ),
  ),
  'spatie/laravel-blade-javascript' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\BladeJavaScript\\BladeJavaScriptServiceProvider',
    ),
  ),
  'spatie/laravel-newsletter' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Newsletter\\NewsletterServiceProvider',
    ),
    'aliases' => 
    array (
      'Newsletter' => 'Spatie\\Newsletter\\NewsletterFacade',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'srmklive/paypal' => 
  array (
    'providers' => 
    array (
      0 => 'Srmklive\\PayPal\\Providers\\PayPalServiceProvider',
    ),
    'aliases' => 
    array (
      'PayPal' => 'Srmklive\\PayPal\\Facades\\PayPal',
    ),
  ),
  'stevebauman/location' => 
  array (
    'providers' => 
    array (
      0 => 'Stevebauman\\Location\\LocationServiceProvider',
    ),
    'aliases' => 
    array (
      'Location' => 'Stevebauman\\Location\\Facades\\Location',
    ),
  ),
  'themsaid/laravel-langman' => 
  array (
    'providers' => 
    array (
      0 => 'Themsaid\\Langman\\LangmanServiceProvider',
    ),
  ),
  'tom-lingham/searchy' => 
  array (
    'providers' => 
    array (
      0 => 'TomLingham\\Searchy\\SearchyServiceProvider',
    ),
    'aliases' => 
    array (
      'Searchy' => 'TomLingham\\Searchy\\Facades\\Searchy',
    ),
  ),
  'tymon/jwt-auth' => 
  array (
    'aliases' => 
    array (
      'JWTAuth' => 'Tymon\\JWTAuth\\Facades\\JWTAuth',
      'JWTFactory' => 'Tymon\\JWTAuth\\Facades\\JWTFactory',
    ),
    'providers' => 
    array (
      0 => 'Tymon\\JWTAuth\\Providers\\LaravelServiceProvider',
    ),
  ),
  'unisharp/laravel-filemanager' => 
  array (
    'providers' => 
    array (
      0 => 'UniSharp\\LaravelFilemanager\\LaravelFilemanagerServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'vinkla/alert' => 
  array (
    'providers' => 
    array (
      0 => 'Vinkla\\Alert\\AlertServiceProvider',
    ),
    'aliases' => 
    array (
      'Alert' => 'Vinkla\\Alert\\Facades\\Alert',
    ),
  ),
  'vinkla/hashids' => 
  array (
    'providers' => 
    array (
      0 => 'Vinkla\\Hashids\\HashidsServiceProvider',
    ),
    'aliases' => 
    array (
      'Hashids' => 'Vinkla\\Hashids\\Facades\\Hashids',
    ),
  ),
  'watson/active' => 
  array (
    'providers' => 
    array (
      0 => 'Watson\\Active\\ActiveServiceProvider',
    ),
    'aliases' => 
    array (
      'Active' => 'Watson\\Watson\\Facades\\Active',
    ),
  ),
);