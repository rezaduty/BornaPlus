<?php

return array (
  'supportedLocales' => 
  array (
    'en' => 
    array (
      'name' => 'English',
      'script' => 'Latn',
      'native' => 'English',
      'regional' => 'en_GB',
    ),
  ),
  'useAcceptLanguageHeader' => true,
  'hideDefaultLocaleInURL' => true,
  'localesOrder' => 
  array (
  ),
);

